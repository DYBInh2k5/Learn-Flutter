package com.example.buoi6_navigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
