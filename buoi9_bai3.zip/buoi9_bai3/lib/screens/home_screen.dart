import 'package:flutter/material.dart';
import '../widgets/story_item.dart';
import '../widgets/post_item.dart';
import '../widgets/reels_item.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          // Story
          SizedBox(
            height: 120,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                StoryItem(imageUrl: "https://via.placeholder.com/100", userName: "Bạn"),
                StoryItem(imageUrl: "https://via.placeholder.com/100", userName: "Nam"),
                StoryItem(imageUrl: "https://via.placeholder.com/100", userName: "Huy"),
                StoryItem(imageUrl: "https://via.placeholder.com/100", userName: "Trang"),
              ],
            ),
          ),

          Divider(),

          // Reels
          SizedBox(
            height: 200,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                ReelsItem(videoUrl: "Reels 1", description: "Video vui 1"),
                ReelsItem(videoUrl: "Reels 2", description: "Video vui 2"),
                ReelsItem(videoUrl: "Reels 3", description: "Video vui 3"),
              ],
            ),
          ),

          Divider(),

          // Post
          PostItem(
            userName: "Nguyễn Văn A",
            userAvatar: "https://via.placeholder.com/50",
            content: "Hôm nay trời đẹp quá!",
            imageUrl: "https://via.placeholder.com/300",
            likes: 120,
            comments: 45,
          ),
          PostItem(
            userName: "Trần Thị B",
            userAvatar: "https://via.placeholder.com/50",
            content: "Đi chơi nè 😍",
            imageUrl: "https://via.placeholder.com/300",
            likes: 300,
            comments: 80,
          ),
        ],
      ),
    );
  }
}
