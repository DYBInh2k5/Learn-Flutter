import 'package:flutter/material.dart';

class FriendsScreen extends StatelessWidget {
  final List<Map<String, String>> friends = [
    {"name": "Nguyễn Văn A", "avatar": "https://via.placeholder.com/50"},
    {"name": "Trần Thị B", "avatar": "https://via.placeholder.com/50"},
    {"name": "Lê Văn C", "avatar": "https://via.placeholder.com/50"},
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: friends.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: CircleAvatar(
            backgroundImage: NetworkImage(friends[index]["avatar"]!),
          ),
          title: Text(friends[index]["name"]!),
          trailing: ElevatedButton(
            onPressed: () {},
            child: Text("Kết bạn"),
          ),
        );
      },
    );
  }
}
