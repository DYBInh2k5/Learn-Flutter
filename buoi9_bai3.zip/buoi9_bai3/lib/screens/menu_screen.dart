import 'package:flutter/material.dart';

class MenuScreen extends StatelessWidget {
  final List<Map<String, dynamic>> menuItems = [
    {"icon": Icons.person, "title": "Trang cá nhân"},
    {"icon": Icons.bookmark, "title": "Đã lưu"},
    {"icon": Icons.settings, "title": "Cài đặt"},
    {"icon": Icons.logout, "title": "Đăng xuất"},
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: menuItems.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: Icon(menuItems[index]["icon"]),
          title: Text(menuItems[index]["title"]),
          onTap: () {},
        );
      },
    );
  }
}
