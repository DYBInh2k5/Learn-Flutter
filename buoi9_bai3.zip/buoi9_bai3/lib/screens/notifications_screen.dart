import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
  final List<String> notifications = [
    "Nguyễn Văn A đã thích bài viết của bạn",
    "Trần Thị B đã bình luận ảnh của bạn",
    "Bạn có 3 lời mời kết bạn mới",
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemCount: notifications.length,
      separatorBuilder: (context, index) => Divider(),
      itemBuilder: (context, index) {
        return ListTile(
          leading: Icon(Icons.notifications),
          title: Text(notifications[index]),
        );
      },
    );
  }
}
