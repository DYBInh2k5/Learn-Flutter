import 'package:flutter/material.dart';

class PostItem extends StatelessWidget {
  final String userName;
  final String userAvatar;
  final String content;
  final String imageUrl;
  final int likes;
  final int comments;

  const PostItem({
    super.key,
    required this.userName,
    required this.userAvatar,
    required this.content,
    required this.imageUrl,
    required this.likes,
    required this.comments,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(backgroundImage: NetworkImage(userAvatar)),
              const SizedBox(width: 10),
              Text(userName, style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 10),
          Text(content),
          const SizedBox(height: 10),
          Image.network(imageUrl),
          const SizedBox(height: 5),
          Row(
            children: [
              Icon(Icons.thumb_up_alt_outlined),
              const SizedBox(width: 5),
              Text("$likes"),
              const SizedBox(width: 15),
              Icon(Icons.comment_outlined),
              const SizedBox(width: 5),
              Text("$comments bình luận"),
            ],
          ),
        ],
      ),
    );
  }
}
