import 'package:flutter/material.dart';

class ReelsItem extends StatelessWidget {
  final String videoUrl;
  final String description;

  const ReelsItem({super.key, required this.videoUrl, required this.description});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 150,
      margin: const EdgeInsets.symmetric(horizontal: 5),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.3),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          Center(
            child: Icon(Icons.play_circle, size: 50),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(description),
          ),
        ],
      ),
    );
  }
}
