import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/profile_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Buoi 9 - Named Routes',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // Định nghĩa các route
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/profile': (context) => ProfileScreen(name: '',), // dữ liệu sẽ truyền sau
      },
    );
  }
}
