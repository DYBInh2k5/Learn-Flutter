import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const ProfileScreen(),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  // --- Các hàm mở liên kết ---
  Future<void> _openFacebook() async {
    final Uri url = Uri.parse('https://www.facebook.com/binhdzkosai18cm');
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw 'Không mở được Facebook!';
    }
  }

  Future<void> _sendEmail() async {
    final Uri email = Uri(
      scheme: 'mailto',
      path: 'binh.vd01500@sinhvien.hoasen.edu.vn',
      query: 'subject=Liên hệ từ ứng dụng Flutter',
    );
    if (!await launchUrl(email)) {
      throw 'Không mở được email!';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        title: const Text("Danh thiếp cá nhân"),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Ảnh đại diện
            const CircleAvatar(
              radius: 60,
              backgroundImage: NetworkImage('https://img.thuthuatphanmem.vn/uploads/2018/09/26/hinh-nen-chu-meo-con-giua-nhung-bong-hoa-dep_053030421.jpg'),
            ),

            const SizedBox(height: 20),

            // Tên
            const Text(
              "Võ Duy Bình",
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Colors.blueAccent,
              ),
            ),

            const SizedBox(height: 8),

            // Nghề nghiệp
            const Text(
              "Sinh viên Kỹ thuật phần mềm",
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),

            const SizedBox(height: 8),

            // Email
            const Text(
              "📧 binh.vd01500@sinhvien.hoasen.edu.vn",
              style: TextStyle(
                fontSize: 14,
                color: Colors.black87,
                fontStyle: FontStyle.italic,
              ),
            ),

            const SizedBox(height: 30),

            // Nút bấm
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: _openFacebook,
                  icon: const Icon(Icons.facebook),
                  label: const Text("Facebook"),
                ),
                const SizedBox(width: 20),
                ElevatedButton.icon(
                  onPressed: _sendEmail,
                  icon: const Icon(Icons.email),
                  label: const Text("Email"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}