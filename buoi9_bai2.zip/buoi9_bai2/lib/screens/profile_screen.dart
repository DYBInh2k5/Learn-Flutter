import 'package:flutter/material.dart';
import '../models/user.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = ModalRoute.of(context)!.settings.arguments as User;

    return Scaffold(
      appBar: AppBar(title: Text("Profile")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Tên: ${user.name}", style: TextStyle(fontSize: 20)),
            Text("Email: ${user.email}", style: TextStyle(fontSize: 20)),
            SizedBox(height: 10),
            Text("Facebook:"),
            Text(user.facebook, style: TextStyle(color: Colors.blue)),
          ],
        ),
      ),
    );
  }
}
