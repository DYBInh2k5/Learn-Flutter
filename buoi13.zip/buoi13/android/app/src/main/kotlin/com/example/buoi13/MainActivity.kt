package com.example.buoi13

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
