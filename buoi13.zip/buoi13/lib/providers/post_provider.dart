import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/post.dart';
import 'package:uuid/uuid.dart';

final postStreamProvider = StreamProvider.autoDispose<List<Post>>((ref) {
  final snapshots = FirebaseFirestore.instance
      .collection('posts')
      .orderBy('createdAt', descending: true)
      .snapshots();

  return snapshots.map((snapshot) => snapshot.docs
      .map((doc) => Post.fromDoc(doc))
      .toList());
});

final postControllerProvider = Provider((ref) => PostController());

class PostController {
  final CollectionReference posts = FirebaseFirestore.instance.collection('posts');

  Future<void> addPost({required String author, required String content}) async {
    final id = const Uuid().v4();
    final data = {
      'id': id,
      'author': author,
      'content': content,
      'createdAt': FieldValue.serverTimestamp(),
    };
    await posts.doc(id).set(data);
  }

  Future<void> deletePost(String id) async {
    await posts.doc(id).delete();
  }
}
  