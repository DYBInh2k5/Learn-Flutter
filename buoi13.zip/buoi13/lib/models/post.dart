import 'package:cloud_firestore/cloud_firestore.dart';

class Post {
  final String id;
  final String author;
  final String content;
  final DateTime createdAt;

  Post({
    required this.id,
    required this.author,
    required this.content,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'author': author,
        'content': content,
        'createdAt': Timestamp.fromDate(createdAt),
      };

  factory Post.fromDoc(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    final ts = data['createdAt'];
    DateTime created;
    if (ts is Timestamp) {
      created = ts.toDate();
    } else if (ts is String) {
      created = DateTime.parse(ts);
    } else {
      created = DateTime.now();
    }
    return Post(
      id: data['id'] ?? doc.id,
      author: data['author'] ?? 'Ẩn danh',
      content: data['content'] ?? '',
      createdAt: created,
    );
  }
}
