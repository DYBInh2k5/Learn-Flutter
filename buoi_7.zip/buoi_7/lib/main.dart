import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Buổi 7 - State & Input',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HelloUserScreen(),
    );
  }
}

class HelloUserScreen extends StatefulWidget {
  const HelloUserScreen({super.key});

  @override
  State<HelloUserScreen> createState() => _HelloUserScreenState();
}

class _HelloUserScreenState extends State<HelloUserScreen> {
  // Controller để lấy dữ liệu từ ô nhập
  final TextEditingController _nameController = TextEditingController();

  // Biến lưu tên người dùng
  String _userName = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Buổi 7 - Xin chào người dùng"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "Nhập tên của bạn:",
              style: TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 10),

            // Ô nhập tên
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: "Nhập tên tại đây",
              ),
            ),

            const SizedBox(height: 20),

            // Nút bấm
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _userName = _nameController.text;
                });
              },
              child: const Text("Hiển thị lời chào"),
            ),

            const SizedBox(height: 30),

            // Hiển thị kết quả
            Text(
              _userName.isEmpty ? "" : "Xin chào, $_userName!",
              style: const TextStyle(fontSize: 22, color: Colors.blueAccent),
            ),
          ],
        ),
      ),
    );
  }
}